


function sliceString() {

    str ='The Quick Brown Fox';
    res = '';
    
var sen= document.getElementById("result6");

res= str.slice(0, 5);

sen.innerHTML += res;
console.log(res);


}





