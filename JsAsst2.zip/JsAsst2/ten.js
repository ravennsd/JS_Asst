


function pattern() {


    
var PRI= document.getElementById("result10");

for (var i=0; i<4; i++) {
   
    for(var j=0; j<=i; j++){

        res = "*";

        PRI.innerHTML += res;

    }
   
    PRI.innerHTML += "</br>";
    console.log(res);
    
}
       

}
