


function javas() {

    str ='JAVASCRIPT';
    res = '';
    
var PRI= document.getElementById("result9");

for (var x of str) {
   
    res += x;
    
    
    console.log(res);
    PRI.innerHTML += res + "</br>";

    // document.write("</br>");

   
  }
  x++;
  

}
