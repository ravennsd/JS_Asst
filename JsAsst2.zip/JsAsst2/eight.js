

function sortArr(order)
{
    var stringobj=[];
stringobj= [
    {firstName:document.getElementById("text1").value ,lastName:document.getElementById("texta").value},
    {firstName:document.getElementById("text2").value ,lastName:document.getElementById("textb").value},
    {firstName:document.getElementById("text3").value ,lastName:document.getElementById("textc").value},
]

var inArr = [];
inArr= stringobj;
res=[];

    for (var order in stringobj) {
        
        inArr.sort(function(a,b)  {

            const fNamea =a.firstName.toUpperCase();
            const fNameb =b.firstName.toUpperCase();

            if(fNamea[order]>fNameb[order])
            {
                
                return 1;
                
                res+=inArr;
                
            }

            
            else if (fNamea[order]<fNameb[order]) {
         
            return -1;
            
           res= inArr;
            }
            else
            return 0;
                    
                
        })
      
        }
    res+=inArr;
    document.getElementById("result8a").innerHTML +=res;  
    console.log(inArr);
      
        
    }

function sortArrLN(order)
    {
        var stringobj=[];
        stringobj= [
            {firstName:document.getElementById("text1").value ,lastName:document.getElementById("texta").value},
            {firstName:document.getElementById("text2").value ,lastName:document.getElementById("textb").value},
            {firstName:document.getElementById("text3").value ,lastName:document.getElementById("textc").value},
        ]
        
        var inArr = [];
        inArr= stringobj;
        res=[];


        for (var order in stringobj) {
            
            inArr.sort(function(a,b)  {
    
                const lNamea =a.lastName.toUpperCase();
                const lNameb =b.lastName.toUpperCase();
    
                if(lNamea[order]>lNameb[order])
                {
                    
                    return 1;
                    res =inArr;
                }
                
                else if (lNamea[order]<lNameb[order]) {
             
                return -1;
                
               res=inArr;
                }
                else
                return 0;
                        
                    
            })
        
            }
            
        res+=inArr; // for loop printing
        document.getElementById("result8b").innerHTML+= inArr;  
        console.log(inArr);
          
            
        }
    


